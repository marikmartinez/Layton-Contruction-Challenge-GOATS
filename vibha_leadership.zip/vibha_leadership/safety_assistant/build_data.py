"""Builds data.json for the Layton Safety Assistant page from the clean tables."""
import pandas as pd, numpy as np, json
O = '/home/claude/out/'
ASOF = pd.Timestamp('2026-09-30')
j = pd.read_csv(O+'job_summary.csv', parse_dates=['PROJECT_START_DATE', 'PLANNED_COMPLETION_DATE'])
d = pd.read_csv(O+'daily_clean.csv', parse_dates=['JOURNAL_DATE'])
i = pd.read_csv(O+'incidents_clean.csv', parse_dates=['INCIDENT_DATE'])
s = pd.read_csv(O+'issues_clean.csv', parse_dates=['OPEN_DATE', 'DUE_DATE', 'CLOSURE_DATE'])
g = pd.read_csv(O+'good_catches_clean.csv', parse_dates=['REPORT_DATE'])
ck = pd.read_csv('/mnt/user-data/uploads/ab594be3-checklists.csv', parse_dates=['CHECKLIST_DATE'])
mp = pd.read_csv(O+'hazard_family_map.csv')
fmap = lambda src: dict(mp[mp.SOURCE == src][['ORIGINAL_CATEGORY', 'HAZARD_FAMILY']].values)
s['FAM'] = s.HAZARD_CATEGORY.map(fmap('Issue')); g['FAM'] = g.HAZARD_CATEGORY.map(fmap('Good Catch')); i['FAM'] = i.HAZARD_SUBCATEGORY.map(fmap('Incident'))
gap = pd.read_csv(O+'theme_d_hazard_gap.csv')
gapi = gap.set_index('HAZARD_FAMILY')
under = dict(zip(gap.HAZARD_FAMILY, (gap.RECORDABLE_SHARE-gap.ATTENTION_SHARE).clip(lower=0)))
start = j.set_index('JOB_ID').PROJECT_START_DATE
jn = j.set_index('JOB_ID').JOB_NAME

def signals(job, t):
    o = s[(s.JOB_ID == job) & (s.OPEN_DATE <= t) & ((s.CLOSURE_DATE.isna()) | (s.CLOSURE_DATE > t))]
    od = o[o.DUE_DATE < t]
    rec = i[(i.JOB_ID == job) & (i.INCIDENT_DATE <= t) & (i.INCIDENT_DATE > t-pd.Timedelta(days=90))]
    age = (t-start[job]).days
    return dict(overdue=len(od), overdue_crit=int((od.SEVERITY == 'Critical').sum()), recent_inc=len(rec), recent_rec=int(rec.IS_RECORDABLE.sum()),
                first90=bool(0 <= age < 90), age=age, od_fams=od.FAM.value_counts().to_dict(), rec_fams=rec.FAM.value_counts().to_dict(),
                rec_last=rec.sort_values('INCIDENT_DATE').iloc[-1].to_dict() if len(rec) else None)

# ---------- BACK-TEST: score at quarter start using only what was known then; outcome = serious injuries that quarter
d['Q'] = d.JOURNAL_DATE.dt.to_period('Q'); i['Q'] = i.INCIDENT_DATE.dt.to_period('Q')
def backtest(evidence_only):
    rows = []
    for q in pd.period_range('2024Q2', '2026Q3', freq='Q'):
        t = q.start_time-pd.Timedelta(days=1)
        for job, h in d[d.Q == q].groupby('JOB_ID').TOTAL_HOURS.sum().items():
            sg = signals(job, t) if start[job] <= t else dict(first90=True, overdue_crit=0, recent_rec=0, recent_inc=0)
            if start[job] > t: sg['first90'] = True
            sc = 2*sg['first90'] + min(sg['recent_rec'], 3) + 0.3*min(sg['recent_inc'], 5)
            if not evidence_only: sc += 0.4*min(sg['overdue_crit'], 5)
            rows.append(dict(Q=str(q), HOURS=h, SCORE=sc, REC=int(i[(i.JOB_ID == job) & (i.Q == q)].IS_RECORDABLE.sum())))
    bt = pd.DataFrame(rows)
    bt['FLAG'] = bt.groupby('Q').SCORE.transform(lambda x: x >= x.quantile(0.75)) & (bt.SCORE > 0)
    rate = lambda x: x.REC.sum()*2e5/x.HOURS.sum()
    out = {}
    for name, sub in [('train_2024', bt[bt.Q.str.startswith('2024')]), ('test_2025_26', bt[~bt.Q.str.startswith('2024')])]:
        fl, nf = sub[sub.FLAG], sub[~sub.FLAG]
        out[name] = dict(flagged_share_of_hours=round(fl.HOURS.sum()/sub.HOURS.sum(), 3), rec_in_flagged=int(fl.REC.sum()), rec_total=int(sub.REC.sum()),
                         rate_flagged=round(rate(fl), 2), rate_other=round(rate(nf), 2))
    return out
bt_ev = backtest(True); bt_all = backtest(False)
print('evidence only', bt_ev); print('with overdue', bt_all)

# ---------- control playbooks per hazard (what the walk checks / what the PTP covers)
CONTROLS = {
 'Ergonomics & manual lifting': ('Check material is staged where it is used, carts or lift-assists are on site, and team-lift is used for heavy loads.',
                                 'Plan heavy carries before they happen: stage material at point of use and team-lift anything awkward or heavy.'),
 'Falls from height': ('Check ladders are the right type, inspected and tied off; edges and openings guarded; podium ladders used where possible.',
                       'Ladder last: use a lift or podium where you can, three points of contact, and never stand on the top two steps.'),
 'Struck-by': ('Check loads are rigged and tag-lined, exclusion zones are marked, and spotters are used for backing equipment.',
               'Stay out from under suspended loads and make eye contact with operators before crossing their path.'),
 'Caught-in / between': ('Check pinch points are guarded, trench protection is in place, and nobody works between equipment and fixed objects.',
                         'Never put hands or body between moving equipment and a fixed object. Lock out before clearing jams.'),
 'Electrical': ('Check cords and temporary power are inspected, GFCI-protected and routed off walkways.',
                'Inspect cords before use and tag out anything damaged. Treat every circuit as live until tested.'),
 'Slips, trips & housekeeping': ('Check walkways are clear, debris is removed daily, and cords are routed overhead.',
                                 'Clean as you go: keep walkways clear and pick up offcuts before the end of the shift.'),
 'Hot work & fire': ('Check hot work permits, fire watch and extinguishers.', 'Permit, fire watch and extinguisher before any spark.'),
 'Confined space': ('Check permits, atmosphere testing and attendants.', 'No entry without a permit, a test and an attendant.'),
}

# ---------- current watch list for active jobs
active = j[j.PROJECT_STATUS == 'Active'].JOB_ID.tolist()
fams = [f for f in gap.HAZARD_FAMILY if f in CONTROLS]
due = lambda n: (ASOF+pd.Timedelta(days=n)).strftime('%Y-%m-%d')
lta = i[i.IS_LTA == 1].sort_values('INCIDENT_DATE')
recent_lta = lta[lta.INCIDENT_DATE > ASOF-pd.Timedelta(days=120)]
jobs_out, alerts = [], []
for job in active:
    r = j.set_index('JOB_ID').loc[job]; sg = signals(job, ASOF)
    gco = g[(g.JOB_ID == job) & (g.FOLLOW_UP_STATUS == 'Open')]
    fs = {f: 2*sg['rec_fams'].get(f, 0) + 0.5*sg['od_fams'].get(f, 0) + 0.3*(gco.FAM == f).sum() + 10*under.get(f, 0) for f in fams}
    top = max(fs, key=fs.get)
    why = []
    if sg['rec_fams'].get(top): why.append(('evidence', f"{sg['rec_fams'][top]} injur{'y' if sg['rec_fams'][top]==1 else 'ies'} here in this hazard in the last 90 days"))
    if under.get(top, 0) > 0.05: why.append(('evidence', f"across Layton it causes {gapi.loc[top,'RECORDABLE_SHARE']:.0%} of serious injuries but gets {gapi.loc[top,'ATTENTION_SHARE']:.0%} of safety attention"))
    if top == 'Falls from height': why.append(('evidence', f"falls are the most severe injuries: every fall injury was serious, and they caused {int(gapi.loc[top,'LTAS'])} of {int(gap.LTAS.sum())} lost-time injuries"))
    n = int((gco.FAM == top).sum())
    if n: why.append(('process', f"{n} near-miss follow-up(s) on this hazard still open here"))
    # top 2 PTP items
    ptp = [dict(title=f"Focus: {top}", text=CONTROLS[top][1])]
    lt = recent_lta[recent_lta.JOB_ID != job]
    if len(lt):
        x = lt.iloc[-1]; ptp.append(dict(title=f"Lesson from {x.JOB_ID}", text=f"A {x.HAZARD_SUBCATEGORY.lower()} on {x.INCIDENT_DATE:%b %d} kept a worker off work ({x.BODY_PART_INJURED.lower()}). Lessons-learned sheet {x.LTA_LESSON_NUMBER}: read it and check our own setup."))
    elif sg['rec_last']:
        x = sg['rec_last']; ptp.append(dict(title='Our recent injury', text=f"{x['HAZARD_SUBCATEGORY']} injury on {x['INCIDENT_DATE']:%b %d}. What would have prevented it?"))
    jobs_out.append(dict(id=job, name=r.JOB_NAME, type=r.PROJECT_TYPE, state=r.STATE, start=r.PROJECT_START_DATE.strftime('%Y-%m-%d'), age_days=sg['age'],
        rec=int(r.RECORDABLES), lta=int(r.LTAS), hours=round(r.TOTAL_HOURS), overdue_crit=sg['overdue_crit'], recent_inc=sg['recent_inc'], recent_rec=sg['recent_rec'],
        gc_open=len(gco), gc_open_crit=int((gco.POTENTIAL_SEVERITY == 'Critical').sum()), focus=top, walk_check=CONTROLS[top][0], focus_why=why, ptp=ptp))
    # evidence alerts
    if sg['first90']:
        alerts.append(dict(job=job, kind='evidence', signal='Job in its first 90 days', detail=f"Day {sg['age']} of the project. Across Layton, injury rates in the first 90 days are about twice the later rate.",
            action='Run a mobilization safety plan, double superintendent walks, and cover ladders and lifting at orientation', owner='Superintendent', due=due(7), sev='Critical'))
    if sg['recent_rec'] > 0:
        alerts.append(dict(job=job, kind='evidence', signal='Serious injury in the last 90 days', detail=f"{sg['recent_rec']} recordable injur{'y' if sg['recent_rec']==1 else 'ies'} here since {(ASOF-pd.Timedelta(days=90)):%b %d}.",
            action='Cover what happened at the next PTP and spot-check the same task this week', owner='Superintendent', due=due(7), sev='High'))
    # process alert
    if (gco.POTENTIAL_SEVERITY == 'Critical').sum() > 0:
        alerts.append(dict(job=job, kind='process', signal='Critical near-miss not followed up', detail=f"{int((gco.POTENTIAL_SEVERITY=='Critical').sum())} Critical good catch(es) with follow-up still open.",
            action='Send each item to the person who can fix it, with a due date; escalate after 7 days', owner='Safety Manager', due=due(7), sev='High'))
    # records clean-up (not a risk signal)
    if sg['overdue_crit'] > 0:
        alerts.append(dict(job=job, kind='records', signal='Overdue Critical issues to verify', detail=f"{sg['overdue_crit']} Critical issue(s) show as open past due. Many may already be fixed but never closed in the system.",
            action='Walk each item: close it if fixed, re-plan it if not', owner='Project Engineer', due=due(14), sev='Medium'))
for x in recent_lta.itertuples():
    n = int((lta.HAZARD_SUBCATEGORY == x.HAZARD_SUBCATEGORY).sum()); nj = lta[lta.HAZARD_SUBCATEGORY == x.HAZARD_SUBCATEGORY].JOB_ID.nunique()
    alerts.append(dict(job='ALL', kind='evidence', signal=f'{x.HAZARD_SUBCATEGORY}: lost-time injury at another job', detail=f"{x.JOB_ID} on {x.INCIDENT_DATE:%b %d, %Y}. This same mechanism has caused {n} lost-time injuries at {nj} different jobs.",
        action=f'Send lessons-learned sheet {x.LTA_LESSON_NUMBER} to every superintendent; read it at the next PTP; track sign-off', owner='Safety Director', due=due(7), sev='Critical'))
comp = j[j.PROJECT_STATUS == 'Completed'].JOB_ID
oc = s[s.JOB_ID.isin(comp) & (s.STATUS != 'Closed')]
alerts.append(dict(job='ALL', kind='records', signal='Open issues on finished projects', detail=f"{len(oc)} issues are still open on {oc.JOB_ID.nunique()} completed projects.",
    action='Make issue close-out part of project completion sign-off', owner='Safety Director', due=due(14), sev='High'))
for k, a in enumerate(alerts): a['id'] = f'A{k+1:03d}'

fw = ck[ck.CHECKLIST_TYPE == 'Weekly Focus Walk']
worked = set(zip(d.JOB_ID, d.JOURNAL_DATE))
fw_nowork = float(np.mean([(a, b) not in worked for a, b in zip(fw.JOB_ID, fw.CHECKLIST_DATE)]))
f90 = pd.read_csv(O+'when_first90_summary.csv').set_index('PHASE')
lta_types = lta.HAZARD_SUBCATEGORY.value_counts()
data = dict(asof='2026-09-30',
 kpis=dict(rate=0.92, lta_rate=0.47, recordables=47, ltas=24, first_aid=76, hours=int(d.TOTAL_HOURS.sum()), ptp=0.873, walk=0.832, fw_nowork=round(fw_nowork, 3),
           gc_open=410, gc_open_crit=95, open_issues_completed=int(len(oc)), funnel_above=3, funnel_jobs='JOB-001, JOB-008, JOB-010'),
 hazard_gap=[dict(family=r.HAZARD_FAMILY, attention=round(r.ATTENTION_SHARE, 3), serious=round(r.RECORDABLE_SHARE, 3), serious_n=int(r.RECORDABLES), lta=int(r.LTAS),
                  pct_serious=None if pd.isna(r.PCT_INCIDENTS_RECORDABLE) else round(r.PCT_INCIDENTS_RECORDABLE, 2), label=r.ISSUE_SEVERITY_LABEL) for r in gap.itertuples()],
 first90=dict(rate_first90=round(f90.loc['First 90 days', 'INCIDENT_RATE'], 2), rate_after=round(f90.loc['After day 90', 'INCIDENT_RATE'], 2), higher_early=14, higher_later=12, equal_zero=14),
 lta_repeat=[dict(type=k, count=int(v), jobs=int(lta[lta.HAZARD_SUBCATEGORY == k].JOB_ID.nunique())) for k, v in lta_types.items()],
 backtest=dict(evidence=bt_ev, with_overdue=bt_all), active_jobs=jobs_out, alerts=alerts,
 limits=['Synthetic data. 47 serious injuries is a small sample, so project-level rates are noisy: only 3 of 40 projects sit above the normal range.',
         'Hazard families group issue, good-catch and incident categories by judgement.',
         'The first-90-days gap is portfolio-wide; by project only 14 of 40 show it. It may partly reflect early work activities, not newness alone.',
         'Many "overdue" issues may be record-keeping gaps rather than unfixed hazards.',
         'Associations, not proven causes.'])
json.dump(data, open('data.json', 'w'), separators=(',', ':'), default=str)
print(len(alerts), 'alerts', pd.Series([a['kind'] for a in alerts]).value_counts().to_dict(), 'fw_nowork', round(fw_nowork, 3))
print(pd.Series([x['focus'] for x in jobs_out]).value_counts().to_dict())
print(jobs_out[0]['ptp'])
