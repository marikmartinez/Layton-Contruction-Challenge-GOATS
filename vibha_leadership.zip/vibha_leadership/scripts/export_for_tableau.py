"""Dump the live views to one Excel workbook (one sheet per view) for Tableau, with plain-language
tables for non-technical readers. Re-run after new forms are added, then Refresh in Tableau."""
import sqlite3, pandas as pd, sys
db = sys.argv[1] if len(sys.argv) > 1 else 'layton_safety.db'
out = sys.argv[2] if len(sys.argv) > 2 else 'layton_dashboard_data.xlsx'
c = sqlite3.connect(db); q = lambda s: pd.read_sql(s, c)
sheets = {}
for v in ['hazard_gap','events','first90','by_project_age','lta_timeline','open_good_catches','job_summary','issues','incidents']:
    sheets[v] = q(f'select * from v_{v}')
# plain-language KPI cards
k = q('select * from v_kpis').set_index('KPI').VALUE
fmt = lambda x: f'{x:.0%}' if x < 1.5 else f'{x:.0f}'
sheets['kpis'] = pd.DataFrame([
  (1,'Serious injury rate', f"{k['Safety Incident Rate']:.2f}", 'Recordable injuries per 100 full-time workers a year'),
  (2,'Lost-time injury rate', f"{k['LTA Rate']:.2f}", 'Injuries that kept someone off work, per 100 workers a year'),
  (3,'Serious injuries', f"{k['Recordable injuries']:.0f}", f"{k['Lost-time accidents']:.0f} of them lost-time"),
  (4,'Daily pre-task plans done', f"{k['Daily PTP compliance']:.0%}", 'Share of work days with a PTP'),
  (5,'Weekly site walks done', f"{k['Focus Walk compliance']:.0%}", 'Share of work weeks with a Focus Walk'),
  (6,'Safety issues past due', f"{k['Issues overdue']:.0%}", 'Issues not fixed by their due date'),
  (7,'Near-miss follow-ups still open', f"{k['Good Catch follow-ups open']:.0f}", 'Good catches that still need action')],
  columns=['ORDER','KPI','VALUE','WHAT_IT_MEANS'])
# first 90 days: does attention rise as much as risk?
f = q('select * from v_first90').set_index('PHASE')
rows = []
for name, col in [('Injuries','INCIDENT_RATE'),('Safety issues logged','ISSUE_RATE'),('Good catches reported','GOOD_CATCH_RATE')]:
    a, b = f.loc['First 90 days', col], f.loc['After day 90', col]
    rows.append((name, round(a,2), round(b,2), round(a/b-1,4)))
for name, col in [('Daily pre-task plans done','PTP_COMPLIANCE'),('Weekly site walks done','WALK_COMPLIANCE')]:
    a, b = f.loc['First 90 days', col], f.loc['After day 90', col]
    rows.append((name, round(a,4), round(b,4), round(a/b-1,4)))
sheets['first90_gap'] = pd.DataFrame(rows, columns=['MEASURE','FIRST_90_DAYS','AFTER_DAY_90','CHANGE_IN_FIRST_90_DAYS'])
sheets['first90_gap']['TYPE'] = ['Risk','Attention','Attention','Attention','Attention']
# severity: how often an injury in each hazard is serious vs the label issues get
s = sheets['hazard_gap'].query('INCIDENTS > 0')[['HAZARD_FAMILY','INCIDENTS','RECORDABLES','LTAS','PCT_INCIDENTS_RECORDABLE','ISSUE_SEVERITY_LABEL']].copy()
s.columns = ['HAZARD','INJURIES','SERIOUS_INJURIES','LOST_TIME_INJURIES','SHARE_SERIOUS','SEVERITY_LABEL_ON_ISSUES']
sheets['severity'] = s.sort_values('SHARE_SERIOUS', ascending=False)
# project lookup table in plain words
j = sheets['job_summary']
sheets['project_table'] = pd.DataFrame({'JOB_ID':j.JOB_ID,'PROJECT':j.JOB_NAME,'TYPE':j.PROJECT_TYPE,'STATE':j.STATE,'STATUS':j.PROJECT_STATUS,
  'SERIOUS_INJURY_RATE':j.INCIDENT_RATE.round(2),'ALL_INJURIES':j.INCIDENTS,'SERIOUS_INJURIES':j.RECORDABLES,'LIFTING_INJURIES':j.ERGONOMICS_RECORDABLES,
  'PTP_DONE':j.PTP_COMPLIANCE.round(3),'SITE_WALKS_DONE':j.WALK_COMPLIANCE.round(3),'ISSUES_PAST_DUE':j.ISSUES_OVERDUE,
  'OPEN_FOLLOW_UPS':j.GOOD_CATCH_FOLLOWUPS_OPEN,'HOURS_WORKED':j.TOTAL_HOURS.round(0)})

# quarterly trend: does attention keep up as work grows?
t = q("""WITH h AS (SELECT strftime('%Y',JOURNAL_DATE)||'-Q'||((CAST(strftime('%m',JOURNAL_DATE) AS INT)+2)/3) QTR, SUM(TOTAL_HOURS) HOURS FROM v_daily GROUP BY 1),
 g AS (SELECT strftime('%Y',REPORT_DATE)||'-Q'||((CAST(strftime('%m',REPORT_DATE) AS INT)+2)/3) QTR, COUNT(*) N FROM good_catches GROUP BY 1),
 i AS (SELECT strftime('%Y',OPEN_DATE)||'-Q'||((CAST(strftime('%m',OPEN_DATE) AS INT)+2)/3) QTR, COUNT(*) N FROM issues GROUP BY 1),
 r AS (SELECT strftime('%Y',INCIDENT_DATE)||'-Q'||((CAST(strftime('%m',INCIDENT_DATE) AS INT)+2)/3) QTR, SUM(IS_RECORDABLE) N FROM v_incidents GROUP BY 1)
 SELECT h.QTR, h.HOURS, COALESCE(g.N,0) GOOD_CATCHES, COALESCE(i.N,0) ISSUES, COALESCE(r.N,0) SERIOUS_INJURIES
 FROM h LEFT JOIN g USING(QTR) LEFT JOIN i USING(QTR) LEFT JOIN r USING(QTR) ORDER BY h.QTR""")
t['ATTENTION'] = t.GOOD_CATCHES + t.ISSUES
t['ATTENTION_PER_10K_HOURS'] = (t.ATTENTION * 10000 / t.HOURS).round(1)
t['HOURS_INDEX'] = (t.HOURS / t.HOURS.iloc[0] * 100).round(0)
t['ATTENTION_INDEX'] = (t.ATTENTION / t.ATTENTION.iloc[0] * 100).round(0)
long = pd.concat([pd.DataFrame({'QTR':t.QTR,'SERIES':'Hours worked','INDEX':t.HOURS_INDEX}),
                  pd.DataFrame({'QTR':t.QTR,'SERIES':'Safety checks (issues + good catches)','INDEX':t.ATTENTION_INDEX})])
sheets['trend'] = t; sheets['trend_long'] = long
# open follow-ups by severity (for donut)
sheets['followup_severity'] = q("SELECT POTENTIAL_SEVERITY SEVERITY, COUNT(*) OPEN_FOLLOW_UPS FROM v_open_good_catches GROUP BY 1")

with pd.ExcelWriter(out) as x:
    for name, d in sheets.items():
        for col in d.columns:
            if col.endswith('_DATE') or col == 'WEEK_START': d[col] = pd.to_datetime(d[col])
        d.to_excel(x, sheet_name=name[:31], index=False); print(name, len(d))
print(sheets['kpis'][['KPI','VALUE']].to_string()); print(sheets['first90_gap'].to_string()); print(sheets['severity'].to_string())
