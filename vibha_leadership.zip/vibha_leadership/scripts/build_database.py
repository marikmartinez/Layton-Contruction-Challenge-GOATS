"""Builds layton_safety.db: the six source tables (the app inserts new forms here),
a hazard mapping table, and live SQL views that recompute every dashboard number."""
import sqlite3, pandas as pd, sys, os
SRC = sys.argv[1] if len(sys.argv) > 1 else '/mnt/user-data/uploads/'
DB  = sys.argv[2] if len(sys.argv) > 2 else 'layton_safety.db'
files = {'jobs':'c3cba198-jobs.csv','daily_journals':'38ca0bfd-daily_journals.csv','checklists':'ab594be3-checklists.csv',
         'issues':'568e80a6-issues.csv','good_catches':'4a50e010-good_catches.csv','safety_incidents':'dee8869c-safety_incidents.csv'}
dates = {'jobs':['PROJECT_START_DATE','PLANNED_COMPLETION_DATE'],'daily_journals':['JOURNAL_DATE'],'checklists':['CHECKLIST_DATE'],
         'issues':['OPEN_DATE','DUE_DATE','CLOSURE_DATE'],'good_catches':['REPORT_DATE'],'safety_incidents':['INCIDENT_DATE']}
if os.path.exists(DB): os.remove(DB)
con = sqlite3.connect(DB)
con.executescript(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'schema.sql')).read())
for t,f in files.items():
    p = os.path.join(SRC,f) if os.path.exists(os.path.join(SRC,f)) else os.path.join(SRC,f.split('-',1)[1])
    d = pd.read_csv(p); d.columns=[c.strip() for c in d.columns]
    for c in dates[t]: d[c]=pd.to_datetime(d[c]).dt.strftime('%Y-%m-%d')
    d.to_sql(t, con, if_exists='append', index=False)
con.commit()
for t in files: print(t, con.execute(f'select count(*) from {t}').fetchone()[0])
