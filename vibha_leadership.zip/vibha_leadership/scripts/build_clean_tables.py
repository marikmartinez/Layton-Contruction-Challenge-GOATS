import pandas as pd, numpy as np, sys
U='/mnt/user-data/uploads/'; O='/home/claude/out/'
jobs=pd.read_csv(U+'c3cba198-jobs.csv'); dj=pd.read_csv(U+'38ca0bfd-daily_journals.csv')
ck=pd.read_csv(U+'ab594be3-checklists.csv'); iss=pd.read_csv(U+'568e80a6-issues.csv')
gc=pd.read_csv(U+'4a50e010-good_catches.csv'); inc=pd.read_csv(U+'dee8869c-safety_incidents.csv')
for d,cols in [(jobs,['PROJECT_START_DATE','PLANNED_COMPLETION_DATE']),(dj,['JOURNAL_DATE']),(ck,['CHECKLIST_DATE']),(iss,['OPEN_DATE','DUE_DATE','CLOSURE_DATE']),(gc,['REPORT_DATE']),(inc,['INCIDENT_DATE'])]:
    for c in cols: d[c]=pd.to_datetime(d[c])
for d in (jobs,dj,ck,iss,gc,inc): d['JOB_ID']=d['JOB_ID'].str.strip()
wk=lambda s: s-pd.to_timedelta(s.dt.weekday,unit='D')
ASOF=pd.Timestamp('2026-09-30')
print('--- QUALITY CHECKS')
print('dup journal job/date',dj.duplicated(['JOB_ID','JOURNAL_DATE']).sum(),'| zero-hour rows',(dj.TOTAL_HOURS<=0).sum())
print('hours mismatch',((dj.REGULAR_HOURS+dj.OVERTIME_HOURS-dj.TOTAL_HOURS).abs()>0.11).sum())
ptp=ck[ck.CHECKLIST_TYPE=='Daily PTP']; fw=ck[ck.CHECKLIST_TYPE=='Weekly Focus Walk'].copy()
print('dup ptp',ptp.duplicated(['JOB_ID','CHECKLIST_DATE']).sum())
m=ptp.merge(dj[['JOB_ID','JOURNAL_DATE']],left_on=['JOB_ID','CHECKLIST_DATE'],right_on=['JOB_ID','JOURNAL_DATE'],how='left')
print('ptp rows on non-worked days',m.JOURNAL_DATE.isna().sum())
fw['WEEK']=wk(fw.CHECKLIST_DATE); dj['WEEK']=wk(dj.JOURNAL_DATE)
print('dup fw job/week',fw.duplicated(['JOB_ID','WEEK']).sum())
jw=dj.groupby(['JOB_ID','WEEK']).agg(DAYS=('JOURNAL_DATE','count'),HOURS=('TOTAL_HOURS','sum')).reset_index()
m=fw.merge(jw,on=['JOB_ID','WEEK'],how='left'); print('fw rows in non-worked weeks',m.DAYS.isna().sum())
m=inc.merge(dj,left_on=['JOB_ID','INCIDENT_DATE'],right_on=['JOB_ID','JOURNAL_DATE'],how='left')
print('incidents on non-worked days',m.JOURNAL_ID.isna().sum(), list(m[m.JOURNAL_ID.isna()].INCIDENT_ID))
for n,d,c in [('journal',dj,'JOURNAL_DATE'),('inc',inc,'INCIDENT_DATE'),('issue',iss,'OPEN_DATE'),('gc',gc,'REPORT_DATE')]:
    x=d.merge(jobs[['JOB_ID','PROJECT_START_DATE','PLANNED_COMPLETION_DATE']],on='JOB_ID')
    print(n,'before start',(x[c]<x.PROJECT_START_DATE).sum(),'after planned end',(x[c]>x.PLANNED_COMPLETION_DATE).sum())
# issues
calc=(iss.CLOSURE_DATE.fillna(ASOF)-iss.OPEN_DATE).dt.days
print('days_open mismatch',(calc!=iss.DAYS_OPEN).sum())
od=np.where(iss.CLOSURE_DATE.notna(),iss.CLOSURE_DATE>iss.DUE_DATE,ASOF>iss.DUE_DATE)
print('overdue flag mismatch',(od!=(iss.OVERDUE_FLAG=='Y')).sum())
print('closed w/o closure date',((iss.STATUS=='Closed')&iss.CLOSURE_DATE.isna()).sum(),'| not closed with date',((iss.STATUS!='Closed')&iss.CLOSURE_DATE.notna()).sum())
print('closure before open',(iss.CLOSURE_DATE<iss.OPEN_DATE).sum())
print(pd.crosstab(iss.STATUS,iss.OVERDUE_FLAG))
print(pd.crosstab(iss.HAZARD_CATEGORY,iss.SEVERITY))
print(pd.crosstab(iss.HAZARD_CATEGORY,iss.ROOT_CAUSE))
# incidents
print(pd.crosstab(inc.INCIDENT_CLASSIFICATION,inc.INCIDENT_DESCRIPTION.str.extract(r'(minor injury|serious injury|temporary work restrictions)')[0]))
print('LTA lesson on non-LTA',(inc.LTA_LESSON_NUMBER.notna()&(inc.INCIDENT_CLASSIFICATION!='Lost Time Accident')).sum(),'dup lesson',inc.LTA_LESSON_NUMBER.dropna().duplicated().sum())
print(pd.crosstab(inc.HAZARD_SUBCATEGORY,inc.OSHA_HAZARD_CATEGORY))
print(pd.crosstab(gc.FOLLOW_UP_REQUIRED_FLAG,gc.FOLLOW_UP_STATUS))
# ---- CLEAN
cls={'First Aid':'First Aid','REC':'Recordable','RECR':'Recordable','Lost Time Accident':'Lost Time'}
inc['CLASS_CLEAN']=inc.INCIDENT_CLASSIFICATION.map(cls); inc['IS_RECORDABLE']=(inc.CLASS_CLEAN!='First Aid').astype(int); inc['IS_LTA']=(inc.CLASS_CLEAN=='Lost Time').astype(int)
dj['PTP_SUBMITTED']=dj.merge(ptp.assign(P=1),left_on=['JOB_ID','JOURNAL_DATE'],right_on=['JOB_ID','CHECKLIST_DATE'],how='left').P.fillna(0).astype(int).values
jw=jw.merge(fw[['JOB_ID','WEEK']].drop_duplicates().assign(FOCUS_WALK_SUBMITTED=1),on=['JOB_ID','WEEK'],how='left'); jw['FOCUS_WALK_SUBMITTED']=jw.FOCUS_WALK_SUBMITTED.fillna(0).astype(int)
dj=dj.merge(jw[['JOB_ID','WEEK','FOCUS_WALK_SUBMITTED']],on=['JOB_ID','WEEK'])
dj['OT_PCT']=dj.OVERTIME_HOURS/dj.TOTAL_HOURS; dj['HOURS_PER_WORKER']=dj.TOTAL_HOURS/dj.HEADCOUNT; dj['MONTH']=dj.JOURNAL_DATE.dt.to_period('M').dt.to_timestamp()
ic=inc.merge(dj[['JOB_ID','JOURNAL_DATE','HEADCOUNT','TOTAL_HOURS','OVERTIME_HOURS','OT_PCT','WORK_ACTIVITY','WEATHER','PTP_SUBMITTED','FOCUS_WALK_SUBMITTED']],left_on=['JOB_ID','INCIDENT_DATE'],right_on=['JOB_ID','JOURNAL_DATE'],how='left').drop(columns='JOURNAL_DATE')
ic['MONTH']=ic.INCIDENT_DATE.dt.to_period('M').dt.to_timestamp()
gcmap={'Damaged extension cord was found before tools were used.':'A damaged extension cord was found before tools were energized.','Damaged extension cord was found before tools were energized.':'A damaged extension cord was found before tools were energized.','A damaged extension cord.':'A damaged extension cord was found before tools were energized.','Spotter stopped a backing vehicle before it entered a pedestrian route.':'A spotter stopped a backing vehicle before it entered a pedestrian route.'}
gc['DESCRIPTION_CLEAN']=gc.GOOD_CATCH_DESCRIPTION.replace(gcmap); gc['MONTH']=gc.REPORT_DATE.dt.to_period('M').dt.to_timestamp()
iss['MONTH']=iss.OPEN_DATE.dt.to_period('M').dt.to_timestamp(); iss['IS_OVERDUE']=(iss.OVERDUE_FLAG=='Y').astype(int); iss['IS_UNRESOLVED']=(iss.STATUS!='Closed').astype(int)
iss['DAYS_LATE']=((iss.CLOSURE_DATE.fillna(ASOF)-iss.DUE_DATE).dt.days).clip(lower=0)
def summ(keys):
    a=dj.groupby(keys).agg(DAYS_WORKED=('JOURNAL_DATE','count'),TOTAL_HOURS=('TOTAL_HOURS','sum'),OVERTIME_HOURS=('OVERTIME_HOURS','sum'),AVG_HEADCOUNT=('HEADCOUNT','mean'),PTP_EXPECTED=('JOURNAL_DATE','count'),PTP_SUBMITTED=('PTP_SUBMITTED','sum'))
    w=jw.copy(); w['MONTH']=w.WEEK.dt.to_period('M').dt.to_timestamp()
    a=a.join(w.groupby(keys).agg(FW_EXPECTED=('WEEK','count'),FW_SUBMITTED=('FOCUS_WALK_SUBMITTED','sum')))
    a=a.join(ic.groupby(keys).agg(INCIDENTS_TOTAL=('INCIDENT_ID','count'),RECORDABLES=('IS_RECORDABLE','sum'),LTAS=('IS_LTA','sum')))
    a=a.join(iss.groupby(keys).agg(ISSUES_OPENED=('ISSUE_ID','count'),ISSUES_OVERDUE=('IS_OVERDUE','sum'),ISSUES_UNRESOLVED=('IS_UNRESOLVED','sum'),ISSUES_HIGH_CRIT=('SEVERITY',lambda s:s.isin(['High','Critical']).sum())))
    a=a.join(gc.groupby(keys).agg(GOOD_CATCHES=('GOOD_CATCH_ID','count'),GC_FOLLOWUP_OPEN=('FOLLOW_UP_STATUS',lambda s:(s=='Open').sum())))
    a=a.fillna(0).reset_index()
    a['FIRST_AID']=a.INCIDENTS_TOTAL-a.RECORDABLES
    a['OT_PCT']=a.OVERTIME_HOURS/a.TOTAL_HOURS
    a['INCIDENT_RATE']=a.RECORDABLES*200000/a.TOTAL_HOURS; a['LTA_RATE']=a.LTAS*200000/a.TOTAL_HOURS; a['ALL_INJURY_RATE']=a.INCIDENTS_TOTAL*200000/a.TOTAL_HOURS
    a['PTP_COMPLIANCE']=a.PTP_SUBMITTED/a.PTP_EXPECTED; a['FW_COMPLIANCE']=(a.FW_SUBMITTED/a.FW_EXPECTED).where(a.FW_EXPECTED>0)
    a['ISSUE_OVERDUE_PCT']=(a.ISSUES_OVERDUE/a.ISSUES_OPENED).where(a.ISSUES_OPENED>0)
    a['GOOD_CATCH_RATE']=a.GOOD_CATCHES*200000/a.TOTAL_HOURS; a['ISSUE_RATE']=a.ISSUES_OPENED*200000/a.TOTAL_HOURS
    return a
jc=['JOB_ID','JOB_NAME','PROJECT_TYPE','CITY','STATE','CONTRACT_SIZE','CONTRACT_SIZE_BAND','PROJECT_START_DATE','PLANNED_COMPLETION_DATE','PROJECT_STATUS']
js=jobs[jc].merge(summ(['JOB_ID']),on='JOB_ID'); jm=jobs[jc[:7]+['PROJECT_STATUS']].merge(summ(['JOB_ID','MONTH']),on='JOB_ID')
js.round(4).to_csv(O+'job_summary.csv',index=False); jm.round(4).to_csv(O+'job_month_summary.csv',index=False)
dj.drop(columns=[]).round(4).to_csv(O+'daily_clean.csv',index=False); jw.to_csv(O+'weekly_focus_walk.csv',index=False)
ic.round(4).to_csv(O+'incidents_clean.csv',index=False); iss.to_csv(O+'issues_clean.csv',index=False); gc.to_csv(O+'good_catches_clean.csv',index=False)
print('--- PORTFOLIO'); t=js[['TOTAL_HOURS','RECORDABLES','LTAS','INCIDENTS_TOTAL','PTP_EXPECTED','PTP_SUBMITTED','FW_EXPECTED','FW_SUBMITTED','ISSUES_OPENED','ISSUES_OVERDUE','GOOD_CATCHES']].sum(); print(t)
print('TRIR',t.RECORDABLES*2e5/t.TOTAL_HOURS,'LTA',t.LTAS*2e5/t.TOTAL_HOURS,'PTP',t.PTP_SUBMITTED/t.PTP_EXPECTED,'FW',t.FW_SUBMITTED/t.FW_EXPECTED)
print(js[['JOB_ID','TOTAL_HOURS','RECORDABLES','LTAS','INCIDENT_RATE','PTP_COMPLIANCE','FW_COMPLIANCE','ISSUE_OVERDUE_PCT','GOOD_CATCH_RATE','OT_PCT']].round(3).to_string())
print(js[['INCIDENT_RATE','ALL_INJURY_RATE','PTP_COMPLIANCE','FW_COMPLIANCE','ISSUE_OVERDUE_PCT','GOOD_CATCH_RATE','ISSUE_RATE','OT_PCT','AVG_HEADCOUNT','CONTRACT_SIZE']].corr(method='spearman').round(2).iloc[:2].T)
print('jm month sums check',jm.TOTAL_HOURS.sum(),jm.FW_EXPECTED.sum(),jm.RECORDABLES.sum())
