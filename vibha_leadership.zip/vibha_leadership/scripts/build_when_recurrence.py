import pandas as pd, numpy as np
O='/home/claude/out/'
d=pd.read_csv(O+'daily_clean.csv',parse_dates=['JOURNAL_DATE','WEEK']); j=pd.read_csv(O+'job_summary.csv',parse_dates=['PROJECT_START_DATE'])
i=pd.read_csv(O+'incidents_clean.csv',parse_dates=['INCIDENT_DATE']); iss=pd.read_csv(O+'issues_clean.csv',parse_dates=['OPEN_DATE'])
g=pd.read_csv(O+'good_catches_clean.csv',parse_dates=['REPORT_DATE']); w=pd.read_csv(O+'weekly_focus_walk.csv',parse_dates=['WEEK'])
st=j.set_index('JOB_ID').PROJECT_START_DATE
age=lambda df,c:(df[c]-df.JOB_ID.map(st)).dt.days
d['AGE']=age(d,'JOURNAL_DATE'); i['AGE']=age(i,'INCIDENT_DATE'); iss['AGE']=age(iss,'OPEN_DATE'); g['AGE']=age(g,'REPORT_DATE'); w['AGE']=age(w,'WEEK').clip(lower=0)
# --- WHEN: by 30-day bucket (first year) + "after 1 year"
def bucket(a): return np.where(a<360,(a//30)*30,360)
for df in (d,i,iss,g,w): df['BUCKET_START']=bucket(df.AGE)
lab=lambda b: f'Day {int(b)+1}-{int(b)+30}' if b<360 else 'After 1 year'
agg=d.groupby('BUCKET_START').agg(HOURS=('TOTAL_HOURS','sum'),WORK_DAYS=('JOURNAL_DATE','count'),PTP_SUBMITTED=('PTP_SUBMITTED','sum'))
agg=agg.join(i.groupby('BUCKET_START').agg(INCIDENTS=('INCIDENT_ID','count'),RECORDABLES=('IS_RECORDABLE','sum'),LTAS=('IS_LTA','sum')))
agg=agg.join(iss.groupby('BUCKET_START').size().rename('ISSUES')).join(g.groupby('BUCKET_START').size().rename('GOOD_CATCHES'))
agg=agg.join(w.groupby('BUCKET_START').agg(WALK_WEEKS=('WEEK','count'),WALKS=('FOCUS_WALK_SUBMITTED','sum'))).fillna(0).reset_index()
agg['PERIOD']=agg.BUCKET_START.map(lab); agg['FIRST_90_DAYS']=np.where(agg.BUCKET_START<90,'First 90 days','After')
for c,n in [('INCIDENTS','INCIDENT_RATE'),('RECORDABLES','RECORDABLE_RATE'),('ISSUES','ISSUE_RATE'),('GOOD_CATCHES','GOOD_CATCH_RATE')]: agg[n]=agg[c]*2e5/agg.HOURS
agg['PTP_COMPLIANCE']=agg.PTP_SUBMITTED/agg.WORK_DAYS; agg['WALK_COMPLIANCE']=agg.WALKS/agg.WALK_WEEKS
agg.round(4).to_csv(O+'when_by_project_age.csv',index=False)
# first-90 vs after summary
def phase(df): return np.where(df.AGE<90,'First 90 days','After day 90')
for df in (d,i,iss,g,w): df['PHASE']=phase(df)
s=d.groupby('PHASE').agg(HOURS=('TOTAL_HOURS','sum'),WORK_DAYS=('JOURNAL_DATE','count'),PTP=('PTP_SUBMITTED','sum'))
s=s.join(i.groupby('PHASE').agg(INCIDENTS=('INCIDENT_ID','count'),RECORDABLES=('IS_RECORDABLE','sum'),LTAS=('IS_LTA','sum')))
s=s.join(iss.groupby('PHASE').size().rename('ISSUES')).join(g.groupby('PHASE').size().rename('GOOD_CATCHES')).join(w.groupby('PHASE').agg(WALK_WEEKS=('WEEK','count'),WALKS=('FOCUS_WALK_SUBMITTED','sum')))
s['SHARE_OF_HOURS']=s.HOURS/s.HOURS.sum(); s['SHARE_OF_INCIDENTS']=s.INCIDENTS/s.INCIDENTS.sum(); s['SHARE_OF_RECORDABLES']=s.RECORDABLES/s.RECORDABLES.sum(); s['SHARE_OF_LTAS']=s.LTAS/s.LTAS.sum()
for c,n in [('INCIDENTS','INCIDENT_RATE'),('RECORDABLES','RECORDABLE_RATE'),('LTAS','LTA_RATE'),('ISSUES','ISSUE_RATE'),('GOOD_CATCHES','GOOD_CATCH_RATE')]: s[n]=s[c]*2e5/s.HOURS
s['PTP_COMPLIANCE']=s.PTP/s.WORK_DAYS; s['WALK_COMPLIANCE']=s.WALKS/s.WALK_WEEKS
s=s.reset_index(); s.round(4).to_csv(O+'when_first90_summary.csv',index=False)
print(s.T.round(3))
# per project first 90 vs after (for drilldown / "21 of 40")
p=d.groupby(['JOB_ID','PHASE']).TOTAL_HOURS.sum().unstack(); q=i.groupby(['JOB_ID','PHASE']).size().unstack().reindex(p.index).fillna(0)
pp=pd.DataFrame({'HOURS_FIRST90':p['First 90 days'],'HOURS_AFTER':p['After day 90'],'INC_FIRST90':q.get('First 90 days',0),'INC_AFTER':q.get('After day 90',0)})
pp['RATE_FIRST90']=pp.INC_FIRST90*2e5/pp.HOURS_FIRST90; pp['RATE_AFTER']=pp.INC_AFTER*2e5/pp.HOURS_AFTER; pp['HIGHER_EARLY']=pp.RATE_FIRST90>pp.RATE_AFTER
pp=pp.reset_index().merge(j[['JOB_ID','JOB_NAME','PROJECT_TYPE','PROJECT_START_DATE']],on='JOB_ID'); pp['STARTED_JAN_2024']=pp.PROJECT_START_DATE=='2024-01-01'
pp.round(4).to_csv(O+'when_by_project.csv',index=False); print('higher early',pp.HIGHER_EARLY.sum(),'of',len(pp))
# --- RECURRENCE: every LTA in order, with repeats of same type across jobs
l=i[i.IS_LTA==1].sort_values('INCIDENT_DATE').copy()
l['OCCURRENCE_OF_THIS_TYPE']=l.groupby('HAZARD_SUBCATEGORY').cumcount()+1
l['TOTAL_OF_THIS_TYPE']=l.groupby('HAZARD_SUBCATEGORY').INCIDENT_ID.transform('count')
l['DAYS_SINCE_PREV_SAME_TYPE']=l.groupby('HAZARD_SUBCATEGORY').INCIDENT_DATE.diff().dt.days
l['DIFFERENT_JOB_FROM_PREV']=l.groupby('HAZARD_SUBCATEGORY').JOB_ID.shift().ne(l.JOB_ID)&l.DAYS_SINCE_PREV_SAME_TYPE.notna()
l=l.merge(j[['JOB_ID','JOB_NAME','PROJECT_TYPE']],on='JOB_ID',how='left')
l['DAYS_INTO_PROJECT']=l.AGE
cols=['INCIDENT_ID','INCIDENT_DATE','JOB_ID','JOB_NAME','PROJECT_TYPE','OSHA_HAZARD_CATEGORY','HAZARD_SUBCATEGORY','BODY_PART_INJURED','LTA_LESSON_NUMBER','OCCURRENCE_OF_THIS_TYPE','TOTAL_OF_THIS_TYPE','DAYS_SINCE_PREV_SAME_TYPE','DIFFERENT_JOB_FROM_PREV','DAYS_INTO_PROJECT']
l[cols].to_csv(O+'recurrence_lta_timeline.csv',index=False)
r=l.groupby('HAZARD_SUBCATEGORY').agg(LTAS=('INCIDENT_ID','count'),JOBS=('JOB_ID','nunique'),FIRST=('INCIDENT_DATE','min'),LAST=('INCIDENT_DATE','max'),MEDIAN_DAYS_BETWEEN=('DAYS_SINCE_PREV_SAME_TYPE','median')).sort_values('LTAS',ascending=False)
r['SHARE_OF_LTAS']=r.LTAS/r.LTAS.sum(); r.reset_index().round(3).to_csv(O+'recurrence_summary.csv',index=False); print(r)
print('LTAs in first 90 days:',(l.AGE<90).sum())
# --- KPI table for dashboard 1 header
gc_fu=g[g.FOLLOW_UP_REQUIRED_FLAG=='Y']
k=pd.DataFrame([
 ('Safety Incident Rate',round(j.RECORDABLES.sum()*2e5/j.TOTAL_HOURS.sum(),2),'(REC+RECR+LTA) x 200,000 / hours'),
 ('LTA Rate',round(j.LTAS.sum()*2e5/j.TOTAL_HOURS.sum(),2),'LTA x 200,000 / hours'),
 ('Recordable injuries',int(j.RECORDABLES.sum()),'plus %d first aid'%int(j.FIRST_AID.sum())),
 ('Daily PTP compliance',round(j.PTP_SUBMITTED.sum()/j.PTP_EXPECTED.sum(),3),'PTPs / worked days'),
 ('Focus Walk compliance',round(j.FW_SUBMITTED.sum()/j.FW_EXPECTED.sum(),3),'walks / worked weeks'),
 ('Issues overdue',round(j.ISSUES_OVERDUE.sum()/j.ISSUES_OPENED.sum(),3),'OVERDUE_FLAG = Y'),
 ('Good Catch follow-ups still open',round((gc_fu.FOLLOW_UP_STATUS=='Open').mean(),3),'open / follow-up required'),
 ('Ergonomics: share of recordables vs attention','32% vs 6%','from theme_d_hazard_gap'),
 ('First 90 days: share of hours vs recordables',f"{s.set_index('PHASE').loc['First 90 days','SHARE_OF_HOURS']:.0%} vs {s.set_index('PHASE').loc['First 90 days','SHARE_OF_RECORDABLES']:.0%}",'from when_first90_summary')],
 columns=['KPI','VALUE','DEFINITION']); k.to_csv(O+'kpi_cards.csv',index=False); print(k)
