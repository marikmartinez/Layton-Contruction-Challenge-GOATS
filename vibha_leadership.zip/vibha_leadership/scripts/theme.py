import sys
from lxml import etree as ET
BG='#0B1220'; CARD='#151E33'; TXT='#E8EDF5'; SUB='#9AA8C2'
src,dst=sys.argv[1],sys.argv[2]
p=ET.XMLParser(remove_blank_text=False)
tree=ET.parse(src,p); wb=tree.getroot()

def rule(style, element, formats):
    r=None
    for x in style.findall('style-rule'):
        if x.get('element')==element: r=x
    if r is None:
        r=ET.SubElement(style,'style-rule',element=element)
    for attr,val,extra in formats:
        for f in r.findall('format'):
            if f.get('attr')==attr and all(f.get(k)==v for k,v in extra.items()) and 'field' not in f.attrib:
                r.remove(f)
        f=ET.SubElement(r,'format',attr=attr,**extra); f.set('value',val)

# workbook-level default font colour
ws_style=wb.find('style')
if ws_style is None:
    ws_style=ET.Element('style'); wb.insert(list(wb).index(wb.find('datasources')),ws_style)
rule(ws_style,'all',[('color',TXT,{})])

for w in wb.find('worksheets'):
    name=w.get('name')
    lo=w.find('layout-options')
    if lo is None:
        lo=ET.Element('layout-options'); w.insert(0,lo)
    t=lo.find('title')
    if t is None:
        t=ET.SubElement(lo,'title'); ft=ET.SubElement(t,'formatted-text'); r=ET.SubElement(ft,'run'); r.text='<Sheet Name>'
    for r in t.iter('run'):
        r.set('fontcolor',TXT); r.set('fontsize','13'); r.set('bold','true')
    table=w.find('table')
    st=table.find('style')
    if st is None:
        st=ET.Element('style'); table.insert(list(table).index(table.find('view'))+1,st)
    rule(st,'table',[('background-color',CARD,{})])
    rule(st,'worksheet',[('color',TXT,{})])
    rule(st,'header',[('color',TXT,{})])
    rule(st,'axis',[('color',SUB,{})])
    rule(st,'label',[('color',TXT,{})])
    rule(st,'cell',[('color',TXT,{})])
    rule(st,'gridline',[('line-visibility','off',{'scope':'rows'}),('line-visibility','off',{'scope':'cols'})])
    rule(st,'table-div',[('line-visibility','off',{'scope':'rows'}),('line-visibility','off',{'scope':'cols'})])

for d in wb.find('dashboards'):
    t=d.find('layout-options/title')
    if t is not None:
        runs=list(t.iter('run'))
        for i,r in enumerate(runs):
            r.set('fontcolor',TXT if i==0 else SUB)
            if i==0: r.set('fontsize','22')
    st=d.find('style')
    if st is None:
        st=ET.Element('style'); d.insert(list(d).index(d.find('size')),st)
    rule(st,'table',[('background-color',BG,{})])
    for z in d.iter('zone'):
        if z.get('name') or z.get('type-v2') in ('color','filter','text','legend'):
            zs=z.find('zone-style')
            if zs is None: zs=ET.SubElement(z,'zone-style')
            for f in zs.findall('format'):
                if f.get('attr') in ('background-color','margin','border-style','border-width','border-color','padding'): zs.remove(f)
            for a,v in [('border-color',CARD),('border-style','none'),('border-width','0'),('margin','6'),('padding','10'),('background-color',CARD)]:
                ET.SubElement(zs,'format',attr=a,value=v)
tree.write(dst,xml_declaration=True,encoding='utf-8')
print('ok')
