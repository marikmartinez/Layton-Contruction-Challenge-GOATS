import pandas as pd, numpy as np
O='/home/claude/out/'
iss=pd.read_csv(O+'issues_clean.csv',parse_dates=['OPEN_DATE']); gc=pd.read_csv(O+'good_catches_clean.csv',parse_dates=['REPORT_DATE'])
inc=pd.read_csv(O+'incidents_clean.csv',parse_dates=['INCIDENT_DATE']); jobs=pd.read_csv(O+'job_summary.csv')
M=[('Issue','Fall Protection','Falls from height'),('Issue','Ladders','Falls from height'),('Issue','Scaffolding','Falls from height'),
('Issue','Ergonomics','Ergonomics & manual lifting'),('Issue','Excavation','Caught-in / between'),('Issue','Struck-By','Struck-by'),
('Issue','Confined Space','Confined space'),('Issue','Fire Prevention','Hot work & fire'),('Issue','Electrical','Electrical'),
('Issue','Housekeeping','Slips, trips & housekeeping'),
('Good Catch','Fall Protection','Falls from height'),('Good Catch','Housekeeping','Slips, trips & housekeeping'),('Good Catch','Electrical','Electrical'),
('Good Catch','Material Handling','Struck-by'),('Good Catch','Struck-By','Struck-by'),
('Incident','Ladder Fall','Falls from height'),('Incident','Fall from Elevated Work Surface','Falls from height'),
('Incident','Same-Level Slip / Trip','Slips, trips & housekeeping'),('Incident','Walking Surface / Debris','Slips, trips & housekeeping'),
('Incident','Manual Material Handling','Ergonomics & manual lifting'),('Incident','Overexertion / Body Mechanics','Ergonomics & manual lifting'),
('Incident','Falling or Shifting Object','Struck-by'),('Incident','Moving Object or Equipment','Struck-by'),
('Incident','Caught in Equipment','Caught-in / between'),('Incident','Caught Between Equipment and Fixed Object','Caught-in / between'),
('Incident','Pinched Between Materials or Components','Caught-in / between'),
('Incident','Temporary Power or Electrical Equipment Contact','Electrical'),('Incident','Contact with Energized Equipment','Electrical'),
('Incident','Thermal Burn / Hot Work','Hot work & fire'),('Incident','Flying Particles / Debris','Flying debris & hand tools'),
('Incident','Hand Tool Cut or Contact','Flying debris & hand tools')]
mp=pd.DataFrame(M,columns=['SOURCE','ORIGINAL_CATEGORY','HAZARD_FAMILY']); mp.to_csv(O+'hazard_family_map.csv',index=False)
f=lambda src: dict(mp[mp.SOURCE==src][['ORIGINAL_CATEGORY','HAZARD_FAMILY']].values)
iss['HAZARD_FAMILY']=iss.HAZARD_CATEGORY.map(f('Issue')); gc['HAZARD_FAMILY']=gc.HAZARD_CATEGORY.map(f('Good Catch')); inc['HAZARD_FAMILY']=inc.HAZARD_SUBCATEGORY.map(f('Incident'))
assert iss.HAZARD_FAMILY.notna().all() and gc.HAZARD_FAMILY.notna().all() and inc.HAZARD_FAMILY.notna().all()
# one row per safety event (best table for Tableau)
ev=pd.concat([
 pd.DataFrame({'EVENT_ID':iss.ISSUE_ID,'EVENT_TYPE':'Issue','JOB_ID':iss.JOB_ID,'EVENT_DATE':iss.OPEN_DATE,'HAZARD_FAMILY':iss.HAZARD_FAMILY,'ORIGINAL_CATEGORY':iss.HAZARD_CATEGORY,'SEVERITY_OR_CLASS':iss.SEVERITY,'IS_ATTENTION':1,'IS_INCIDENT':0,'IS_RECORDABLE':0,'IS_LTA':0,'IS_OVERDUE':iss.IS_OVERDUE}),
 pd.DataFrame({'EVENT_ID':gc.GOOD_CATCH_ID,'EVENT_TYPE':'Good Catch','JOB_ID':gc.JOB_ID,'EVENT_DATE':gc.REPORT_DATE,'HAZARD_FAMILY':gc.HAZARD_FAMILY,'ORIGINAL_CATEGORY':gc.HAZARD_CATEGORY,'SEVERITY_OR_CLASS':gc.POTENTIAL_SEVERITY,'IS_ATTENTION':1,'IS_INCIDENT':0,'IS_RECORDABLE':0,'IS_LTA':0,'IS_OVERDUE':np.nan}),
 pd.DataFrame({'EVENT_ID':inc.INCIDENT_ID,'EVENT_TYPE':'Incident','JOB_ID':inc.JOB_ID,'EVENT_DATE':inc.INCIDENT_DATE,'HAZARD_FAMILY':inc.HAZARD_FAMILY,'ORIGINAL_CATEGORY':inc.HAZARD_SUBCATEGORY,'SEVERITY_OR_CLASS':inc.CLASS_CLEAN,'IS_ATTENTION':0,'IS_INCIDENT':1,'IS_RECORDABLE':inc.IS_RECORDABLE,'IS_LTA':inc.IS_LTA,'IS_OVERDUE':np.nan})])
ev=ev.merge(jobs[['JOB_ID','JOB_NAME','PROJECT_TYPE','STATE','CONTRACT_SIZE_BAND','PROJECT_STATUS']],on='JOB_ID')
ev['YEAR']=ev.EVENT_DATE.dt.year; ev.to_csv(O+'theme_d_events.csv',index=False)
# portfolio hazard gap table
fams=sorted(mp.HAZARD_FAMILY.unique())
g=ev.groupby('HAZARD_FAMILY').agg(ISSUES=('EVENT_TYPE',lambda s:(s=='Issue').sum()),GOOD_CATCHES=('EVENT_TYPE',lambda s:(s=='Good Catch').sum()),
  ATTENTION=('IS_ATTENTION','sum'),INCIDENTS=('IS_INCIDENT','sum'),RECORDABLES=('IS_RECORDABLE','sum'),LTAS=('IS_LTA','sum'),ISSUES_OVERDUE=('IS_OVERDUE','sum')).reindex(fams).fillna(0)
g['FIRST_AID']=g.INCIDENTS-g.RECORDABLES
g['ATTENTION_SHARE']=g.ATTENTION/g.ATTENTION.sum(); g['RECORDABLE_SHARE']=g.RECORDABLES/g.RECORDABLES.sum()
g['LTA_SHARE']=g.LTAS/g.LTAS.sum(); g['INCIDENT_SHARE']=g.INCIDENTS/g.INCIDENTS.sum()
g['FAIR_SHARE_INDEX']=(g.ATTENTION_SHARE/g.RECORDABLE_SHARE).replace(np.inf,np.nan)
g['GAP_PCT_POINTS']=(g.RECORDABLE_SHARE-g.ATTENTION_SHARE)*100
g['PCT_INCIDENTS_RECORDABLE']=(g.RECORDABLES/g.INCIDENTS).where(g.INCIDENTS>0)
sev=iss.groupby('HAZARD_FAMILY').SEVERITY.agg(lambda s:'/'.join(sorted(s.unique())))
g['ISSUE_SEVERITY_LABEL']=sev.reindex(fams).fillna('No issue category')
g['ISSUE_OVERDUE_PCT']=(g.ISSUES_OVERDUE/g.ISSUES).where(g.ISSUES>0)
g['PROJECTS_WITH_RECORDABLE']=inc[inc.IS_RECORDABLE==1].groupby('HAZARD_FAMILY').JOB_ID.nunique().reindex(fams).fillna(0)
g['ATTENTION_PER_RECORDABLE']=(g.ATTENTION/g.RECORDABLES).replace(np.inf,np.nan)
from scipy.stats import binomtest
g['P_VALUE_UNDERWATCHED']=[binomtest(int(r),int(g.RECORDABLES.sum()),a,alternative='greater').pvalue if a>0 else np.nan for r,a in zip(g.RECORDABLES,g.ATTENTION_SHARE)]
g=g.sort_values('GAP_PCT_POINTS',ascending=False).reset_index(); g.round(4).to_csv(O+'theme_d_hazard_gap.csv',index=False)
# project x hazard (for drill-down)
ph=ev.groupby(['JOB_ID','HAZARD_FAMILY']).agg(ATTENTION=('IS_ATTENTION','sum'),INCIDENTS=('IS_INCIDENT','sum'),RECORDABLES=('IS_RECORDABLE','sum'),LTAS=('IS_LTA','sum')).reset_index()
full=pd.MultiIndex.from_product([jobs.JOB_ID,fams],names=['JOB_ID','HAZARD_FAMILY']).to_frame(index=False)
ph=full.merge(ph,how='left').fillna(0)
t=ph.groupby('JOB_ID')[['ATTENTION','INCIDENTS']].transform('sum')
ph['ATTENTION_SHARE_IN_JOB']=ph.ATTENTION/t.ATTENTION; ph['INCIDENT_SHARE_IN_JOB']=(ph.INCIDENTS/t.INCIDENTS).where(t.INCIDENTS>0)
ph=ph.merge(jobs[['JOB_ID','JOB_NAME','PROJECT_TYPE','STATE','CONTRACT_SIZE_BAND','PROJECT_STATUS','TOTAL_HOURS']],on='JOB_ID')
ph['ATTENTION_PER_200K_HRS']=ph.ATTENTION*2e5/ph.TOTAL_HOURS
ph.round(4).to_csv(O+'theme_d_project_hazard.csv',index=False)
# year x hazard (does the gap persist?)
yh=ev.groupby(['YEAR','HAZARD_FAMILY']).agg(ATTENTION=('IS_ATTENTION','sum'),INCIDENTS=('IS_INCIDENT','sum'),RECORDABLES=('IS_RECORDABLE','sum')).reset_index()
yt=yh.groupby('YEAR')[['ATTENTION','INCIDENTS','RECORDABLES']].transform('sum')
yh['ATTENTION_SHARE']=yh.ATTENTION/yt.ATTENTION; yh['INCIDENT_SHARE']=yh.INCIDENTS/yt.INCIDENTS; yh['RECORDABLE_SHARE']=yh.RECORDABLES/yt.RECORDABLES
yh.round(4).to_csv(O+'theme_d_year_hazard.csv',index=False)
print(g[['HAZARD_FAMILY','ATTENTION','RECORDABLES','LTAS','ATTENTION_SHARE','RECORDABLE_SHARE','FAIR_SHARE_INDEX','PCT_INCIDENTS_RECORDABLE','ISSUE_SEVERITY_LABEL','PROJECTS_WITH_RECORDABLE','P_VALUE_UNDERWATCHED']].round(3).to_string())
print(yh[yh.HAZARD_FAMILY=='Ergonomics & manual lifting'].round(3).to_string())
print(len(ev),len(ph),len(yh))
