import re, uuid, pandas as pd
src,dst=sys_argv=__import__('sys').argv[1:3]
t=open(src).read()
X='/home/claude/out/db/layton_dashboard_data.xlsx'
# --- 1. KPI row for 485 open issues on completed projects
k=pd.read_excel(X,sheet_name='kpis')
if 8 not in k.ORDER.values:
    k.loc[len(k)]=[8,'Issues open on finished projects','485','Safety issues never closed before 18 projects finished']
with pd.ExcelWriter(X,mode='a',engine='openpyxl',if_sheet_exists='replace') as x: k.to_excel(x,sheet_name='kpis',index=False)
t=t.replace('gridOrigin="A1:D8:no:A1:D8:0"','gridOrigin="A1:D9:no:A1:D9:0"').replace('&quot;A1:D8:no:A1:D8:0&quot;','&quot;A1:D9:no:A1:D9:0&quot;').replace('"A1:D8:no:A1:D8:0"','"A1:D9:no:A1:D9:0"')
# --- 2. Page 2: after-day-90 bars grey
t=t.replace('<map to="#4e79a7">\n              <bucket>"After day 90"</bucket>','<map to="#5B6B8C">\n              <bucket>"After day 90"</bucket>')
# --- 3. new datasources cloned from followup_severity
i=t.find('<datasource caption="followup_severity'); e=t.find('</datasource>',i)+13
tmpl=t[i:e]
def make_ds(sheet, cols, rng):
    name='federated.'+uuid.uuid4().hex[:28]
    oid=sheet.replace('_','!',1)+'_'+uuid.uuid4().hex.upper()
    colxml=''.join(f'\n            <column datatype="{dt}" name="{c}" ordinal="{n}"/>' for n,(c,dt) in enumerate(cols))
    rel=f'<relation connection="excel-direct.0ggjsrd1ojkwwc138trau1rvrrhg" name="{sheet}" table="[{sheet}$]" type="table">\n          <columns gridOrigin="{rng}" header="yes" outcome="6">{colxml}\n          </columns>\n        </relation>'
    cap=lambda c: c.replace('_',' ').title()
    roles=''.join(f'\n      <column caption="{cap(c)}" datatype="{dt}" name="[{c}]" role="{"dimension" if dt=="string" else "measure"}" type="{"nominal" if dt=="string" else "quantitative"}"/>' for c,dt in cols)
    ds=f'''<datasource caption="{sheet} (layton_dashboard_data)" inline="true" name="{name}" version="18.1">
      <connection class="federated">
        <named-connections>
          <named-connection caption="layton_dashboard_data" name="excel-direct.0ggjsrd1ojkwwc138trau1rvrrhg">
            <connection class="excel-direct" cleaning="no" compat="no" dataRefreshTime="" filename="/Users/vibhakaranth/Downloads/layton_dashboard_data.xlsx" interpretationMode="0" password="" server="" validate="no"/>
          </named-connection>
        </named-connections>
        {rel}
      </connection>
      <aliases enabled="yes"/>{roles}
      <column caption="{sheet}" datatype="table" name="[__tableau_internal_object_id__].[{oid}]" role="measure" type="quantitative"/>
      <layout dim-ordering="alphabetic" measure-ordering="alphabetic" show-structure="true"/>
      <object-graph>
        <objects>
          <object caption="{sheet}" id="{oid}">
            <properties context="">
              {rel}
            </properties>
          </object>
        </objects>
      </object-graph>
    </datasource>'''
    return name, ds
split_name, split_ds = make_ds('first90_split',[('GROUP','string'),('PROJECTS','integer'),('ORDER','integer')],'A1:C4:no:A1:C4:0')
fun_name, fun_ds = make_ds('funnel',[('JOB_ID','string'),('PROJECT','string'),('HOURS_WORKED','real'),('SERIOUS_INJURIES','real'),('PROJECT_RATE','real'),('UPPER_LIMIT','real'),('LOWER_LIMIT','real'),('PORTFOLIO_AVERAGE','real')],'A1:H101:no:A1:H101:0')
t=t.replace('</datasources>', split_ds+'\n    '+fun_ds+'\n  </datasources>',1)
# --- 4. split worksheet cloned from first-90 gap sheet
i=t.find('<worksheet name="First 90 days'); e=t.find('</worksheet>',i)+12
w=t[i:e]
w=w.replace('First 90 days: injuries double (+107%) but safety checks barely rise','Not every project: 14 of 40 had more serious injuries early')
old='federated.0td2rs40pff87r1egekci0slu60l'
w=w.replace(old,split_name).replace('first90_gap (layton_dashboard_data)','first90_split (layton_dashboard_data)')
deps=f'''<datasource-dependencies datasource="{split_name}">
            <column caption="Group" datatype="string" name="[GROUP]" role="dimension" type="nominal"/>
            <column caption="Projects" datatype="integer" name="[PROJECTS]" role="measure" type="quantitative"/>
            <column caption="Order" datatype="integer" name="[ORDER]" role="measure" type="quantitative"/>
            <column-instance column="[GROUP]" derivation="None" name="[none:GROUP:nk]" pivot="key" type="nominal"/>
            <column-instance column="[PROJECTS]" derivation="Sum" name="[sum:PROJECTS:qk]" pivot="key" type="quantitative"/>
            <column-instance column="[ORDER]" derivation="Sum" name="[sum:ORDER:qk]" pivot="key" type="quantitative"/>
          </datasource-dependencies>'''
w=re.sub(r'<datasource-dependencies.*?</datasource-dependencies>',deps,w,flags=re.S)
w=re.sub(r'<shelf-sorts>.*?</shelf-sorts>',f'<computed-sort column="[{split_name}].[none:GROUP:nk]" direction="ASC" using="[{split_name}].[sum:ORDER:qk]"/>',w,flags=re.S)
w=w.replace('[sum:CHANGE_IN_FIRST_90_DAYS:qk]','[sum:PROJECTS:qk]').replace('[none:MEASURE:nk]','[none:GROUP:nk]').replace('[none:TYPE:nk]','[none:GROUP:nk]')
w=w.replace('value="Change in first 90 days vs. later"','value="Number of projects"')
w=re.sub(r'<simple-id uuid="[^"]*"/>','<simple-id uuid="{%s}"/>'%str(uuid.uuid4()).upper(),w)
t=t[:e]+'\n    '+w+t[e:]
# palette for split groups on its datasource
pal='<style><style-rule element="mark"><encoding attr="color" field="[none:GROUP:nk]" type="palette"><map to="#E15759"><bucket>"Higher in first 90 days"</bucket></map><map to="#5B6B8C"><bucket>"Higher after day 90"</bucket></map><map to="#3A4766"><bucket>"Same (no serious injuries)"</bucket></map></encoding></style-rule></style>'
t=t.replace(f'<layout dim-ordering="alphabetic" measure-ordering="alphabetic" show-structure="true"/>\n      <object-graph>\n        <objects>\n          <object caption="first90_split"', f'<layout dim-ordering="alphabetic" measure-ordering="alphabetic" show-structure="true"/>\n      {pal}\n      <object-graph>\n        <objects>\n          <object caption="first90_split"')
# window entry for new sheet
t=t.replace('</windows>','  <window class="worksheet" name="Not every project: 14 of 40 had more serious injuries early"><cards><edge name="left"><strip size="160"><card type="pages"/><card type="filters"/><card type="marks"/></strip></edge></cards></window>\n  </windows>',1)
# rename page-2 title sheet to soften claim
t=t.replace('First 90 days: injuries double (+107%) but safety checks barely rise','Across the portfolio, first-90-day injuries are 2x, but safety checks barely rise')
open(dst,'w').write(t); print('ok',split_name,fun_name)
