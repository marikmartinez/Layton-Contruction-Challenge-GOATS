import sys
from lxml import etree as ET
BG='#0B1220'; CARD='#151E33'; BAND='#1B2642'; TXT='#E8EDF5'; SUB='#9AA8C2'
src,dst=sys.argv[1],sys.argv[2]
tree=ET.parse(src); wb=tree.getroot()
def rule(style, element, formats):
    r=next((x for x in style.findall('style-rule') if x.get('element')==element),None)
    if r is None: r=ET.SubElement(style,'style-rule',element=element)
    for attr,val,extra in formats:
        for f in r.findall('format'):
            if f.get('attr')==attr and 'field' not in f.attrib and all(f.get(k)==v for k,v in extra.items()): r.remove(f)
        f=ET.SubElement(r,'format',attr=attr,**extra); f.set('value',val)
    return r
ws=wb.find('style')
if ws is None:
    ws=ET.Element('style'); wb.insert(list(wb).index(wb.find('datasources')),ws)
rule(ws,'all',[('color',TXT,{})])
for w in wb.find('worksheets'):
    lo=w.find('layout-options')
    if lo is None: lo=ET.Element('layout-options'); w.insert(0,lo)
    t=lo.find('title')
    if t is None:
        t=ET.SubElement(lo,'title'); ft=ET.SubElement(t,'formatted-text'); r=ET.SubElement(ft,'run'); r.text='<Sheet Name>'
    for r in t.iter('run'): r.set('fontcolor',TXT); r.set('fontsize','13'); r.set('bold','true')
    table=w.find('table'); st=table.find('style')
    if st is None: st=ET.Element('style'); table.insert(list(table).index(table.find('view'))+1,st)
    rule(st,'table',[('background-color',CARD,{})])
    for el in ('worksheet','header','label','cell'): rule(st,el,[('color',TXT,{})])
    rule(st,'axis',[('color',SUB,{})])
    rule(st,'gridline',[('line-visibility','off',{'scope':'rows'}),('line-visibility','off',{'scope':'cols'})])
    rule(st,'table-div',[('line-visibility','off',{'scope':'rows'}),('line-visibility','off',{'scope':'cols'})])
    rule(st,'pane',[('band-color',BAND,{'scope':'rows'})])
    rule(st,'header',[('band-color',BAND,{'scope':'rows'})])
    if w.get('name').startswith('410 near-miss'):
        for p in table.find('panes'):
            if p.get('id')=='2':
                s=p.find('style'); r=rule(s,'mark',[('mark-color',CARD,{}),('size','0.55',{})])
            if p.get('id')=='1':
                if p.find('mark-sizing') is None: p.insert(list(p).index(p.find('mark'))+1,ET.Element('mark-sizing',**{'mark-sizing-setting':'marks-scaling-off'}))
                s=p.find('style'); rule(s,'mark',[('size','1.15',{})])
# palettes on datasources
def palette(dsname, field, mapping):
    for ds in wb.find('datasources'):
        if ds.get('name')!=dsname: continue
        st=ds.find('style')
        if st is None:
            st=ET.Element('style'); lay=ds.find('layout'); ds.insert(list(ds).index(lay)+1 if lay is not None else len(ds),st)
        r=next((x for x in st.findall('style-rule') if x.get('element')=='mark'),None) or ET.SubElement(st,'style-rule',element='mark')
        for e in r.findall('encoding'):
            if e.get('field')==field: r.remove(e)
        e=ET.SubElement(r,'encoding',attr='color',field=field,type='palette')
        for k,v in mapping.items():
            m=ET.SubElement(e,'map',to=v); b=ET.SubElement(m,'bucket'); b.text='"%s"'%k
        print('palette set',dsname)
palette('federated.0imyq8l0lvskm81enxnqs16g39gr','[none:SEVERITY:nk]',{'Critical':'#e15759','High':'#f28e2b','Medium':'#edc948'})
palette('federated.0q4pvlx0ur04ty1b6j0b51hjsv3b','[none:SERIES:nk]',{'Hours worked':'#8c9bb8','Safety checks (issues + good catches)':'#76b7b2'})
titles={
 '1. Where Are We Watching':('1 / WHERE  ·  Are we watching the right hazards?','Lifting causes a third of serious injuries, yet gets 6% of inspections and near-miss reports, and its issues are labeled Low.'),
 '2. When and What Keeps Happening':('2 / WHEN  ·  Risk spikes early and grows with the work. Safety checks do not.','Injury rate doubles in a project\'s first 90 days, the same lost-time injuries repeat across jobs, and checks stayed flat while hours grew 2.6x.'),
 '3. What Needs Action Now':('3 / ACT  ·  What needs attention now?','Click a project in the table to see its open near-miss follow-ups. Ask the Safety Assistant for details on any project or hazard.')}
for d in wb.find('dashboards'):
    lo=d.find('layout-options')
    if lo is None: lo=ET.Element('layout-options'); d.insert(0,lo)
    t=lo.find('title')
    if t is None: t=ET.SubElement(lo,'title')
    for c in list(t): t.remove(c)
    ft=ET.SubElement(t,'formatted-text')
    a,b=titles.get(d.get('name'),(d.get('name'),''))
    r=ET.SubElement(ft,'run',bold='true',fontcolor=TXT,fontsize='20'); r.text=a
    r=ET.SubElement(ft,'run'); r.text='Æ\n'
    r=ET.SubElement(ft,'run',fontcolor=SUB,fontsize='12'); r.text=b
    st=d.find('style')
    if st is None: st=ET.Element('style'); d.insert(list(d).index(d.find('size')),st)
    rule(st,'table',[('background-color',BG,{})])
    for z in d.iter('zone'):
        if z.get('name') or z.get('type-v2') in ('color','filter','text'):
            zs=z.find('zone-style')
            if zs is None: zs=ET.SubElement(z,'zone-style')
            for f in zs.findall('format'):
                if f.get('attr') in ('background-color','margin','border-style','border-width','border-color','padding'): zs.remove(f)
            for k,v in [('border-color',CARD),('border-style','none'),('border-width','0'),('margin','6'),('padding','10'),('background-color',CARD)]:
                ET.SubElement(zs,'format',attr=k,value=v)
tree.write(dst,xml_declaration=True,encoding='utf-8')
print('written')
