# Leadership view: Tableau dashboard + Layton Safety Assistant (Vibha)

Theme D: **"We're watching the wrong places."** This folder holds the leadership side of the team solution. It has two parts: a 3-page Tableau dashboard and the Safety Assistant web page.

## What's here

| Folder | Contents |
|---|---|
| `tableau/` | `Layton_Theme_D_Dashboard.twb` (Tableau workbook) and `layton_dashboard_data.xlsx` (the data it reads) |
| `safety_assistant/` | `index.html`, the Safety Assistant page (data is already embedded), with `build_data.py` / `data.json` used to make it |
| `database/` | `layton_safety.db` (SQLite) and `schema.sql` |
| `data_clean/` | Cleaned CSV tables built from the Layton 2026 dataset |
| `scripts/` | Python used to clean the data, build the database, export the Excel file for Tableau and style the workbook |

Live Safety Assistant: https://claude.ai/artifact/S9UqJwyGTDbSayHTGbgtg3

## Dashboard story (3 pages)

1. **WHERE: Are we watching the right hazards?** Lifting/ergonomics causes 32% of serious injuries but gets about 6% of inspections and near-miss reports, and its issues are labeled Low. The summary strip shows a serious injury rate of 0.92, PTPs done 87%, and 22% of Focus Walks filed on days with no work.
2. **WHEN: Risk spikes early and grows with the work.** Across the whole portfolio, the injury rate in the first 90 days is about 2x the later rate (4.15 vs 2.01). This is a portfolio pattern and does not hold on every job. The same lost-time injuries repeat across jobs, and checks stayed flat while hours grew 2.6x.
3. **ACT: What needs attention now?** Click any project for an "Open Safety Assistant →" link. A project lookup table and 410 open near-miss follow-ups (95 Critical). A funnel plot shows that only 3 of 40 projects (JOB-001, 008, 010) sit above the normal range, so ranking projects is mostly noise.

## Safety Assistant (AI feature)

- **Role toggle:** Executive, Safety Director and Superintendent.
- **Alert playbook:** alerts are tagged Evidence, Process or Records. Done ticks are saved.
- **Focus walks:** gives each active job a focus hazard, a walk check and PTP items.
- **PTP talk drafter:** writes this week's pre-task talk in English or Spanish. A superintendent must review the draft.

The AI redirects the existing attention budget (Focus Walks and PTPs) toward the hazards that actually hurt people. It does not add more paperwork.

## Honest limits (from the team critique)

- The first-90-days effect is portfolio-wide only: 14 jobs are higher early, 12 higher later and 14 equal.
- Checklist completion did not predict injuries.
- Back-test of the evidence-only flag:
  - 2025–26: flagged quarters had a rate of 0.95 vs 0.54 for the rest, and caught 11 of 25 serious injuries on 31% of the hours.
  - 2024: it did not work (0.89 vs 1.72).
- Overdue issues on finished projects (485) may partly be a records problem, not just open risk.

## How to open

1. **Tableau:** open `tableau/Layton_Theme_D_Dashboard.twb` in Tableau Desktop. When asked, point it to `layton_dashboard_data.xlsx` in the same folder. If a chart shows blank, use **Data → [source] → Refresh**.
2. **Safety Assistant:** open the live link above. `index.html` also works in a browser, but the AI drafting needs the live version.
3. **Rebuild the data:** run `python scripts/build_clean_tables.py`, then `build_database.py`, then `export_for_tableau.py`.
